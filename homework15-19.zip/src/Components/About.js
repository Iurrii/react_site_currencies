import React from 'react';
import './About.css'


class About extends React.Component {
  // constructor(props) {
  //     super(props);
  // }
  render() {
    return (
      <div className="">
        <p>About</p>

      </div>
    )
  }
};

export default About;